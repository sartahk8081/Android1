package com.example.myapplicationfui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Home extends AppCompatActivity {
    TextView t1_txt,t2_txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        t1_txt=findViewById(R.id.t1);
        t2_txt=findViewById(R.id.t2);
         Intent in = getIntent();
         String e = in.getStringExtra("usname");
         String p = in.getStringExtra("upw");
          t1_txt.setText(e);
          t2_txt.setText(p);

    }

}
