package com.example.myapplicationfui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {
    EditText usname, upw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        usname = findViewById(R.id.username);
        upw = findViewById(R.id.password);
    }
    public void login(View view) {
        String e = usname.getText().toString();
        String p = upw.getText().toString();
        if(e.isEmpty()){
            usname.setError("Enter the User Name");
            return;
        }
        if(p.isEmpty()){
            upw.setError("Enter the Password");
            return;
        }
//        Toast.makeText(this,e+ "  " +p, Toast.LENGTH_SHORT).show();

        Intent in =new Intent(getApplicationContext(),Home.class);
        in.putExtra("usname",e);
        in.putExtra("upw",p);
        startActivity(in);
    }
}
